import time
from random import randint
from pyfirmata import Arduino, util, OUTPUT

# BOARD CONFIGURATION (Create an Arduino board instance)
board = Arduino("COM9")

# ITERATOR
it = util.Iterator(board)
it.start()

# Set up analog pins for input
analog_button_pins = [0, 1, 2, 3, 4]  # Analog pins (A0, A1, A2, A3, A4)
buttons = [board.analog[pin] for pin in analog_button_pins]

# Enable reporting for analog pins
for button in buttons:
    button.enable_reporting()

# Set up digital pins for output
digital_computerchoiceLED_pins = [12,11,10,9,8]
computerchoice_LED = [board.digital[pin] for pin in digital_computerchoiceLED_pins]
#COULD BE REMOVED
for led in computerchoice_LED:
    led.mode = OUTPUT

# Set up indicator LED pin
digital_indicatorLED_pins = [6]
indicator_LED = [board.digital[pin] for pin in digital_indicatorLED_pins]

# Score LED
digital_scoreLED_pins = [5,4,3,2]
score_LED = [board.digital[pin] for pin in digital_scoreLED_pins]

# Set up BUZZER pin
digital_buzzer_pins = [7]
buzzer = [board.digital[pin] for pin in digital_buzzer_pins]

gestures = ["Rock", "Paper", "Scissors", "Liazrd", "$pock"]
computer_score = 0
player_score =  0
round = 1

rules = {
    "RP":False,"RS":True,"RL":True,"R$":False,
    "PR":True,"PS":False,"PL":False,"P$":True,
    "SR":False,"SP":True,"SL":True,"S$":False,
    "LR":False,"LP":True,"LS":False,"L$":True,
    "$R":True,"$P":False,"$S":True,"$L":False
    }

def play_tone(frequency, duration):
    if frequency == 0:  # If frequency is 0, stop the buzzer
        buzzer[0].write(0)
    else:
        period = 1.0 / frequency  # Calculate the period of the tone
        delay = period / 2  # Half period for the high and low states
        cycles = int(duration * frequency)  # Calculate the number of cycles

        for _ in range(cycles):
            buzzer[0].write(1)  # Turn the buzzer on
            time.sleep(delay)
            buzzer[0].write(0)  # Turn the buzzer off
            time.sleep(delay)

def player_input():
    print("Choose a Gesture.....")
    indicator_LED[0].write(1)
    start_time = time.time()
    while True:
        current_time = time.time()
        if current_time - start_time >3:
            indicator_LED[0].write(0)
            print("Time Over")
            return None
        for i, button in enumerate(buttons):
            button_value = button.read()
            if button_value is not None:
                # Convert the analog value to a range between 0 and 1
                # and consider a threshold to determine if the button is pressed
                if button_value > 0.5:  # Adjust this threshold as needed
                    indicator_LED[0].write(0)
                    play_tone(100, 0.1)
                    print(f"You Chose {gestures[i]}")
                    time.sleep(2)
                    return gestures[i]
        else: #Will be executed if no break was encountered in the for loop
            time.sleep(0.02)  # Add a small delay to avoid overwhelming the serial interface
            continue #Continue the while loop

def computer_input():
    global k 
    k = randint(0,4)
    print(f"Computer Chose {gestures[k]}")
    return gestures[k]

def light_computerchoice_LED():
    computerchoice_LED[k].write(1)
    time.sleep(2)
    computerchoice_LED[k].write(0)

def computer_score_display():
    if computer_score == 1:
        score_LED[3].write(1)
    elif computer_score == 2:
        score_LED[3].write(0)
        score_LED[2].write(1)
    elif computer_score == 3:
        score_LED[3].write(1)
        score_LED[2].write(1)
    
def player_score_display():
    if player_score == 1:
        score_LED[1].write(1)
    elif player_score == 2:
        score_LED[1].write(0)
        score_LED[0].write(1)
    elif player_score == 3:
        score_LED[1].write(1)
        score_LED[0].write(1)

def computer_wins():
    for i in range(5):
        score_LED[2].write(1)
        score_LED[3].write(1)
        time.sleep(0.25)
        score_LED[2].write(0)
        score_LED[3].write(0)
        time.sleep(0.25)
        score_LED[0].write(0)
        score_LED[1].write(0)

def player_wins():
    for i in range(5):
        score_LED[0].write(1)
        score_LED[1].write(1)
        time.sleep(0.25)
        score_LED[0].write(0)
        score_LED[1].write(0)
        time.sleep(0.25)
        score_LED[2].write(0)
        score_LED[3].write(0)

def main():
    global computer_score
    global player_score
    computer_score = 0
    player_score =  0
    round = 1
    while computer_score != 4 and player_score != 4:
        print("Round :", round)
        print(f"Computer Score : {computer_score}")
        print(f"Player Score : {player_score}")
        time.sleep(1)
        player_choice = player_input()
        if player_choice == None:
            play_tone(4,1)
            print("No Input was chosen. Computer gets a point")
            time.sleep(1)
            computer_score = computer_score + 1
            computer_score_display()
            round = round + 1
            continue
        computer_choice = computer_input()
        light_computerchoice_LED()
        if computer_choice == player_choice:
            print("It's a Draw")
            time.sleep(2)
            continue
        else:
            outcome = player_choice[0] + computer_choice[0]
            if rules[outcome]:
                print("You win")
                time.sleep(1)
                player_score = player_score + 1
                player_score_display()
                round = round + 1
            else:
                print("Computer wins")
                time.sleep(1)
                computer_score = computer_score + 1
                computer_score_display()
                round = round + 1
        
        
    
    if computer_score == 4:
        computer_wins()
    elif player_score == 4:
        player_wins()


if __name__=="__main__":
    main()